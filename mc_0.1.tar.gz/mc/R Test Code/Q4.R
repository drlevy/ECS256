Q4 <- function(testQ1 = FALSE, testQ2 = FALSE, testQ3 = FALSE)
{
  vmax = 10
  values = c(1:vmax)
  prob = c(1:vmax)
  values_in_new_box = c(rep(0,length(prob)))
  constant = vmax/sum(prob)
  prob = constant*values/vmax
  current_weight = 0
  number_of_boxes = 1
  boxes_total_weight = 0
  items = 100000
  sampled_values = sample(values, items, TRUE, prob)
  for(i in 1:items)
  {
    random_value = sampled_values[i]
    boxes_total_weight = boxes_total_weight + random_value
    
    current_weight = current_weight + random_value
    if( current_weight > vmax )
    {
      number_of_boxes = number_of_boxes + 1
      current_weight = random_value
      values_in_new_box[random_value] = values_in_new_box[random_value] + 1
    }
  }
  
  number_of_items_per_box = items/number_of_boxes
  average_weight_per_box = boxes_total_weight/number_of_boxes
  
  values_in_new_box = values_in_new_box/number_of_boxes
  
  if(testQ1 == TRUE)
  {
    return(number_of_items_per_box)
  }
  if(testQ2 == TRUE)
  {
    return(average_weight_per_box)
  }
  if(testQ3 == TRUE)
  {
    return(values_in_new_box)
  }
}

MatrixTransitions <- function(i,j, wmax, prob)
{
  if(i >= j)
  {
    if( (i+j) <= wmax ) # i am going to state less than me but i can't start a new box
    {
      return(0)
    }
    else #i am going to a state less than me and the only way to get there is to get that weight item since i will start a new box
    {
      return(prob[j])
    }
  }
  else
  {
    if( (i+j) <= wmax )#i am going to a state ahead of me but we can't start a new box in that state so i just use a smaller weight to get there
    {
      return(prob[j-i])
    }
    else
    {
      return(prob[j-i] + prob[j])#i am going to a state ahead of me and i can get there by a small weight or by starting a new box at that weight
    }
  }
}

CreateExampleTransitionMatrix <- function(size)
{
  pij = matrix(rep(0,size*size), size, size)
  prob = c(1:size)
  constant = size/sum(prob)
  prob = constant*prob/size
  
  for(i in 1:size)
  {
    for(j in 1:size)
    {
      pij[i,j] = MatrixTransitions(i,j,size,prob)
    }
  }
  
  return(pij)
}

test <- function()
{
  wmax = 10
  pij = CreateExampleTransitionMatrix(10)
  markov = mc(pij)
  pis = stn(markov)
  prob = c(1:wmax)
  constant = wmax/sum(prob)
  prob = constant*prob/wmax
  start = c(rep(0,wmax))
  weights = c(1:wmax)
  
  for(i in 1:wmax)
  {
    numerator = 0
    denominator = 0
    for(j in 1:wmax)
    {
      if( i > (wmax-weights[j]))
      {
        numerator = numerator + pis[j] 
      }
    }
    for(k in 1:wmax)
    {
      sum = 0
      for(j in 1:wmax)
      {
        if(i > (wmax - k))
        {
          sum = sum + pis[j]
        }
      }
      denominator = denominator + sum*prob[k]
    }
    weights[i] = numerator/denominator
  }
  return(weights)
}


test2 <- function()
{
  wmax = 10
  pij = CreateExampleTransitionMatrix(10)
  markov = mc(pij)
  pis = stn(markov)
  prob = c(1:wmax)
  constant = wmax/sum(prob)
  prob = constant*prob/wmax
  start = c(rep(0,wmax))
  weights = c(1:wmax)
  pff = 0
  pnn = 0
  
  for(k in 1:wmax)
  {
    sum = 0
    for(i in 1:wmax)
    {
      if( i <= (wmax-k))
      {
        sum = sum + pis[i]
      }
    }
    pff = pff + sum*prob[k]
  }
  
  for(k in 1:wmax)
  {
    sum = 0
    for(i in 1:wmax)
    {
      if( i > (wmax-k))
      {
        sum = sum + pis[i]
      }
    }
    pnn = pnn + sum*prob[k]
  }
  
  result = 1 + pff/(1-pff)
  return(result)
}

test3 <- function()
{
  wmax = 10
  pij = CreateExampleTransitionMatrix(10)
  markov = mc(pij)
  pis = stn(markov)
  values = c(1:wmax)
  prob = c(1:wmax)
  constant = wmax/sum(prob)
  prob = constant*prob/wmax
  
  for(i in 1:wmax)
  {
    num = 0
    for(j in 1:wmax)
    {
      if( j > (wmax - i))
      {
        num = num + pis[j]
      }
    }
    
    dom = 0
    for(k in 1:wmax)
    {
      sum = 0
      for(j in 1:wmax)
      {
        if( j > (wmax - k))
        {
          sum = sum + pis[j]
        }
      }
      
      dom = dom + sum*prob[k]
    }
    values[i] = num/dom
  }
  
  return(values) 
}

test4 <- function()
{
  wmax = 10
  pij = CreateExampleTransitionMatrix(10)
  markov = mc(pij)
  pis = stn(markov)
  values = c(1:wmax)
  prob = c(1:wmax)
  constant = wmax/sum(prob)
  prob = constant*prob/wmax
  
  sum(1:wmax*pis)
}


